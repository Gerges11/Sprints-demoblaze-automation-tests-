package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class CheckoutInvalidDataTest extends BaseTest {

    @Test
    public void testInvalidCheckoutDataShowsErrors() {
        HomePage home = new HomePage(driver);
        home.searchFor("bag");

        SearchResultsPage searchPage = new SearchResultsPage(driver);
        searchPage.clickOnJoustDuffleBag();

        ProductPage product = new ProductPage(driver);
        product.setQuantity(1);
        product.addToCart();

        CartPage cart = new CartPage(driver);
        cart.openCart();

        CheckoutPage checkout = new CheckoutPage(driver);
        checkout.proceedToCheckout();
        checkout.fillInvalidDetails();

        checkout.placeOrder();

        checkout.closeTab();
        Assert.assertTrue(checkout.isValidationErrorPresent(), "Validation errors were not detected!");

    }
}
