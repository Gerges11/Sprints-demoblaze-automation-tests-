package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;
import pages.ProductPage;

public class AddToCartTest extends BaseTest {

    @Test
    public void testAddItemToCart() {
        HomePage homePage = new HomePage(driver);
        ProductPage productPage = new ProductPage(driver);
        CartPage cartPage = new CartPage(driver);

        homePage.clickOnFirstProduct();
        productPage.addToCart();
        productPage.acceptAlert();

        cartPage.goToCart();
        Assert.assertTrue(cartPage.isCartItemDisplayed(), "Item was not added to the cart.");
    }
}
