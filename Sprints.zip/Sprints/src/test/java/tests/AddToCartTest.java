package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class AddToCartTest extends BaseTest {

    @Test
    public void testAddToCartWithCorrectCalculation() {
        HomePage home = new HomePage(driver);
        home.searchFor("bag");

        SearchResultsPage searchPage = new SearchResultsPage(driver);
        searchPage.clickOnJoustDuffleBag();

        ProductPage product = new ProductPage(driver);
        product.setQuantity(10);
        product.addToCart();

        CartPage cart = new CartPage(driver);
        cart.openCart();

        int qty = cart.getQuantity();
        double price = cart.getProductTotalPrice();

        Assert.assertEquals(qty, 10, "Quantity mismatch");
        Assert.assertTrue(price > 0, "Price calculation failed or zero");
    }
}