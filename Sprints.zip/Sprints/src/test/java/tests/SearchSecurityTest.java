package tests;

import org.openqa.selenium.NoAlertPresentException;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;

public class SearchSecurityTest extends BaseTest {

    @Test
    public void testXSSInjectionInSearch() {
        HomePage home = new HomePage(driver);
        home.searchFor("<script>alert('XSS')</script>");

        // Check that alert did NOT appear
        boolean alertAppeared = isAlertPresent();
        Assert.assertFalse(alertAppeared, "XSS Alert appeared! Vulnerability suspected.");
    }

    @Test
    public void testSQLInjectionInSearch() {
        HomePage home = new HomePage(driver);
        home.searchFor("1' OR '1'='1");

        SearchResultsPage results = new SearchResultsPage(driver);
        Assert.assertTrue(results.isNoResultDisplayed(), "Potential SQL Injection vulnerability detected!");
    }

    private boolean isAlertPresent() {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }
}
