package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import org.openqa.selenium.NoAlertPresentException;

public class SearchSecurityTest extends BaseTest {

    @Test
    public void testXSSInjectionInSearch() {
        HomePage homePage = new HomePage(driver);
        homePage.search("<script>alert('XSS')</script>");
        Assert.assertFalse(homePage.isScriptExecuted(), "Potential XSS vulnerability detected!");
    }

    @Test
    public void testSQLInjectionInSearch() {
        HomePage homePage = new HomePage(driver);
        homePage.search("1' OR '1'='1");
        Assert.assertTrue(homePage.isNoSearchResultDisplayed(), "Potential SQL Injection vulnerability!");
    }
}
