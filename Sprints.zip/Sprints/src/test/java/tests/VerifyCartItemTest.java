package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;
import pages.ProductPage;


public class VerifyCartItemTest extends BaseTest {

    @Test
    public void testItemAppearsInCart() {
        HomePage homePage = new HomePage(driver);
        homePage.clickOnFirstProduct();

        ProductPage productPage = new ProductPage(driver);
        productPage.clickAddToCart();

        driver.navigate().to("https://www.demoblaze.com/cart.html");

        CartPage cartPage = new CartPage(driver);
        Assert.assertTrue(cartPage.isItemInCart(), "Item was not found in the cart!");
    }
}