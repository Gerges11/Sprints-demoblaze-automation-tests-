package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;

public class SearchInvalidTest extends BaseTest {

    @Test
    public void testInvalidSearchShowsNoResults() {
        HomePage home = new HomePage(driver);
        home.searchFor("fish");

        SearchResultsPage searchPage = new SearchResultsPage(driver);
        Assert.assertTrue(searchPage.isNoResultDisplayed(), "No results message not shown!");
    }
}