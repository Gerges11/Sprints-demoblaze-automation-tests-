package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;

public class SearchInvalidTest extends BaseTest {

    @Test
    public void testInvalidSearchShowsNoResults() {
        HomePage homePage = new HomePage(driver);
        homePage.search("asdkjashdklashd"); // Nonsense keyword

        Assert.assertTrue(homePage.isNoSearchResultDisplayed(), "Expected no results, but some were displayed.");
    }
}
