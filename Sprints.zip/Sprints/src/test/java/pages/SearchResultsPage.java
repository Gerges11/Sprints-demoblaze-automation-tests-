package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchResultsPage {
    private WebDriver driver;

    private By noResultMsg = By.xpath("//*[contains(text(),'Your search returned no results.')]");
    private By joustBagLink = By.linkText("Joust Duffle Bag");

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isNoResultDisplayed() {
        return driver.findElements(noResultMsg).size() > 0;
    }

    public void clickOnJoustDuffleBag() {
        driver.findElement(joustBagLink).click();
    }
}