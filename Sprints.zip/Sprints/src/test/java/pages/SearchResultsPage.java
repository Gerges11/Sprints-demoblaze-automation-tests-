package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchResultsPage {
    WebDriver driver;

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public ProductPage openProductByName(String productName) {
        By productLink = By.linkText(productName); // Or use xpath if needed
        driver.findElement(productLink).click();
        return new ProductPage(driver);
    }
    public boolean isNoResultsDisplayed() {
        try {
            WebElement noResults = driver.findElement(By.xpath("//*[contains(text(),'No results')]"));
            return noResults.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

}
