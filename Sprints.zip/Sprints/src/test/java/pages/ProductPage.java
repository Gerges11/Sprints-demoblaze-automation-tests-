package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

public class ProductPage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By quantityInput = By.id("qty");
    private By addToCartButton = By.id("product-addtocart-button");

    public ProductPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void setQuantity(int qty) {
        WebElement qtyInput = wait.until(ExpectedConditions.visibilityOfElementLocated(quantityInput));
        qtyInput.clear();
        qtyInput.sendKeys(String.valueOf(qty));
    }

    public void addToCart() {
        WebElement addBtn = wait.until(ExpectedConditions.elementToBeClickable(addToCartButton));
        addBtn.click();
        // Wait for confirmation (e.g., success message appearing)
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".message-success")));
    }
}
