package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
    private WebDriver driver;
    private By addToCartButton = By.xpath("//a[text()='Add to cart']");

    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    public void addToCart() {
        driver.findElement(addToCartButton).click();
    }

    public void acceptAlert() {
        try {
            Thread.sleep(2000); // Better to use WebDriverWait
            Alert alert = driver.switchTo().alert();
            alert.accept();
        } catch (Exception e) {
            System.out.println("No alert present or couldn't accept it: " + e.getMessage());
        }
    }

    public void clickAddToCart() {
        addToCart();
        acceptAlert();
    }
}