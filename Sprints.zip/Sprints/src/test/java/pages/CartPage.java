package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

public class CartPage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By cartLink = By.cssSelector("a.showcart");              // opens minicart drawer
    private By viewCartLink = By.cssSelector("a.action.viewcart"); // "Go to Cart" inside drawer
    private By productPrice = By.cssSelector(".cart.item .price"); // in full cart page
    private By quantityInput = By.cssSelector("input.input-text.qty");

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void openCart() {
        wait.until(ExpectedConditions.elementToBeClickable(cartLink)).click();
        wait.until(ExpectedConditions.elementToBeClickable(viewCartLink)).click();
        // Now you're on the full cart page
        wait.until(ExpectedConditions.visibilityOfElementLocated(productPrice));
    }

    public double getProductTotalPrice() {
        WebElement priceElem = wait.until(ExpectedConditions.visibilityOfElementLocated(productPrice));
        String text = priceElem.getText().replace("$", "").trim();
        return Double.parseDouble(text);
    }

    public int getQuantity() {
        WebElement qty = wait.until(ExpectedConditions.visibilityOfElementLocated(quantityInput));
        return Integer.parseInt(qty.getAttribute("value"));
    }
}
