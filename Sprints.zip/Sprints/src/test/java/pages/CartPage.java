package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
    private WebDriver driver;

    private By cartLink = By.id("cartur");
    private By cartItem = By.xpath("//tr[@class='success']");

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public void goToCart() {
        driver.findElement(cartLink).click();
    }

    public boolean isCartItemDisplayed() {
        return driver.findElements(cartItem).size() > 0;
    }

    public boolean isItemInCart() {
        return isCartItemDisplayed();
    }
}
