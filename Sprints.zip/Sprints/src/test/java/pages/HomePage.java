package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class HomePage {
    private WebDriver driver;

    private By firstProduct = By.xpath("//div[@id='tbodyid']//a[contains(@class, 'hrefch')]");
    private By productNames = By.cssSelector("#tbodyid .card-title");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickOnFirstProduct() {
        driver.findElements(firstProduct).get(0).click();
    }

    public void search(String keyword) {
        // Demoblaze does not have a search field, this is illustrative only
        // Implement your own logic if using a different e-commerce site
        System.out.println("Search is not available on Demoblaze - keyword: " + keyword);
    }

    public boolean isNoSearchResultDisplayed() {
        List<WebElement> products = driver.findElements(productNames);
        return products.isEmpty();
    }
    public boolean isScriptExecuted() {
        try {
            driver.switchTo().alert();
            return true; // Alert appeared, meaning script was executed
        } catch (NoAlertPresentException e) {
            return false; // No alert, so script was not executed (safe)
        }
    }

}