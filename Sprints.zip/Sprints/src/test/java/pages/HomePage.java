package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HomePage {
    private WebDriver driver;

    private By searchInput = By.id("search");
    private By searchButton = By.cssSelector("button[title='Search']");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void searchFor(String searchText) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement searchInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("search")));
        searchInput.clear();
        searchInput.sendKeys(searchText);

        // Wait for the button to become clickable and enabled
        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[title='Search']")));
        searchButton.click();
    }

}
