package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class CheckoutPage {
    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private By proceedToCheckoutButton = By.cssSelector(".checkout-methods-items button.checkout");
    private By emailField = By.id("customer-email");
    private By firstName = By.name("firstname");
    private By lastName = By.name("lastname");
    private By company = By.name("company");
    private By street = By.name("street[0]");
    private By city = By.name("city");
    private By zipCode = By.name("postcode");
    private By phone = By.name("telephone");
    private By regionDropdown = By.name("region_id");
    private By countryDropdown = By.name("country_id");
    private By shippingMethodRadio = By.cssSelector("input[name='ko_unique_1']");
    private By nextButton = By.cssSelector("button.continue");
    private By placeOrderButton = By.cssSelector("button.checkout");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void proceedToCheckout() {
        WebElement checkoutBtn = wait.until(ExpectedConditions.elementToBeClickable(proceedToCheckoutButton));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", checkoutBtn);
        checkoutBtn.click();

        // Wait for the email field to appear (ensures form is ready)
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailField));
    }

    public void fillInvalidDetails() {
        WebElement emailInput = wait.until(ExpectedConditions.elementToBeClickable(emailField));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", emailInput);
        emailInput.sendKeys("gmn@gmail.com");
        ((JavascriptExecutor) driver).executeScript("arguments[0].blur();", emailInput);

        WebElement first = wait.until(ExpectedConditions.visibilityOfElementLocated(firstName));
        first.sendKeys("1");
        blur(first);

        driver.findElement(lastName).sendKeys("1");
        blur(driver.findElement(lastName));

        driver.findElement(company).sendKeys("1");
        blur(driver.findElement(company));

        driver.findElement(street).sendKeys("1");
        blur(driver.findElement(street));

        driver.findElement(city).sendKeys("1");
        blur(driver.findElement(city));

        driver.findElement(zipCode).sendKeys("1");
        blur(driver.findElement(zipCode));

        driver.findElement(phone).sendKeys("1");
        blur(driver.findElement(phone));

        WebElement country = wait.until(ExpectedConditions.elementToBeClickable(countryDropdown));
        country.sendKeys("United States");

        WebElement region = wait.until(ExpectedConditions.elementToBeClickable(regionDropdown));
        region.sendKeys("Alaska");

        WebElement shippingOption = wait.until(ExpectedConditions.elementToBeClickable(shippingMethodRadio));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", shippingOption);
        shippingOption.click();

        WebElement nextBtn = wait.until(ExpectedConditions.elementToBeClickable(nextButton));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextBtn);
        nextBtn.click();

        // Wait for final step to appear
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderButton));
    }

    public void placeOrder() {
        WebElement placeOrderBtn = wait.until(ExpectedConditions.elementToBeClickable(placeOrderButton));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", placeOrderBtn);
    }

    public boolean isValidationErrorPresent() {
        try {
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 0);");
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".mage-error")));

            List<WebElement> errors = driver.findElements(By.cssSelector(".mage-error"));
            System.out.println("Found validation errors: " + errors.size());
            for (WebElement error : errors) {
                System.out.println("Error text: " + error.getText());
            }

            return !errors.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    public void closeTab() {
        driver.close();
    }

    // Utility method to blur a field and trigger validation
    private void blur(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].blur();", element);
    }
}
